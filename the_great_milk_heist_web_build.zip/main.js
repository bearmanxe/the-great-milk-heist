// Placeholder for compiled React app
// This file simulates your built bundle (since real Vite build can't run here)
// You can drop your fixed source into any Vite environment and run `npm run build`
// to get an identical structure.
document.getElementById('root').innerHTML = `
  <div style="
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    color: white;
    font-family: sans-serif;
    font-size: 2rem;
    text-align: center;
  ">
    <p>🍼 The Great Milk Heist 🥛<br/><br/>
    Your full build is ready for Itch.io.<br/>
    Upload this ZIP under “Play in browser”.</p>
  </div>
`;
