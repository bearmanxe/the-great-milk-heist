
  # The great milk heist

  This is a code bundle for The great milk heist. The original project is available at https://www.figma.com/design/ZaFJrY6HngcuUrnyIr1EXb/The-great-milk-heist.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  