class BackgroundMusicManager {
  private audio: HTMLAudioElement | null = null;
  private musicVolume = 0.5;
  private isMuted = false;
  private isPlaying = false;
  private loadError = false;

  initialize(audioUrl: string): boolean {
    if (!audioUrl || audioUrl.trim() === '') {
      console.warn('No audio URL provided for background music');
      return false;
    }

    try {
      if (!this.audio) {
        this.audio = new Audio();
        this.audio.loop = true;
        this.audio.volume = this.musicVolume;
        this.audio.preload = 'auto';
        
        // Handle loading errors gracefully
        this.audio.addEventListener('error', (e) => {
          console.warn('Background music file not accessible - using chiptune music instead');
          this.loadError = true;
          // Stop trying to play if there's an error
          this.isPlaying = false;
        });
        
        this.audio.addEventListener('canplaythrough', () => {
          console.log('%c🎵 Background Music: Custom audio loaded successfully!', 'color: #10b981; font-weight: bold');
          console.log('%c✅ Your "Milk Mayhem.mp4" is now playing!', 'color: #10b981');
          this.loadError = false;
        });

        // Set the source after adding event listeners
        this.audio.src = audioUrl;
        this.audio.load();
      }
      return true;
    } catch (error) {
      console.warn('Failed to initialize background music:', error);
      this.loadError = true;
      return false;
    }
  }

  hasLoadError(): boolean {
    return this.loadError;
  }

  play() {
    // Don't try to play if there was a load error
    if (this.loadError) {
      return;
    }
    
    if (this.audio && !this.isPlaying) {
      const playPromise = this.audio.play();
      
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            this.isPlaying = true;
            console.log('Background music started');
          })
          .catch((error) => {
            // Only log autoplay errors, not load errors (those are already logged)
            if (error.name !== 'NotSupportedError') {
              console.warn('Background music autoplay prevented:', error.message);
            }
            // Autoplay is often blocked by browsers until user interaction
          });
      }
    }
  }

  pause() {
    if (this.audio && this.isPlaying) {
      this.audio.pause();
      this.isPlaying = false;
    }
  }

  stop() {
    if (this.audio) {
      this.audio.pause();
      this.audio.currentTime = 0;
      this.isPlaying = false;
    }
  }

  setVolume(volume: number) {
    this.musicVolume = Math.max(0, Math.min(1, volume));
    if (this.audio && !this.isMuted) {
      this.audio.volume = this.musicVolume;
    }
  }

  getVolume(): number {
    return this.musicVolume;
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.audio) {
      this.audio.volume = this.isMuted ? 0 : this.musicVolume;
    }
    return this.isMuted;
  }

  setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.audio) {
      this.audio.volume = muted ? 0 : this.musicVolume;
    }
  }

  isMusicMuted(): boolean {
    return this.isMuted;
  }

  isMusicPlaying(): boolean {
    return this.isPlaying;
  }

  // Restart playback (useful when user interacts with the page)
  resume() {
    this.play();
  }

  destroy() {
    if (this.audio) {
      this.stop();
      this.audio.src = '';
      this.audio = null;
    }
  }
}

export const backgroundMusicManager = new BackgroundMusicManager();