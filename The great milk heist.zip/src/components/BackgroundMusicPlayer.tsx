import { useEffect, useState } from 'react';
import { backgroundMusicManager } from '../utils/backgroundMusicManager';
import { soundManager } from '../utils/soundManager';
import { Volume2, VolumeX } from 'lucide-react';
import { Button } from './ui/button';
import { Slider } from './ui/slider';

interface BackgroundMusicPlayerProps {
  audioUrl: string | null;
  autoPlay?: boolean;
  useChiptune?: boolean;
}

export function BackgroundMusicPlayer({ audioUrl, autoPlay = true, useChiptune = true }: BackgroundMusicPlayerProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(30);
  const [isInitialized, setIsInitialized] = useState(false);
  const [usingChiptune, setUsingChiptune] = useState(false);

  useEffect(() => {
    // If no audio URL provided, use chiptune music
    if (!audioUrl && useChiptune) {
      console.log('%c🎮 Background Music: Using chiptune mode', 'color: #8b5cf6; font-weight: bold');
      console.log('%cℹ️ To use your custom music:', 'color: #6366f1');
      console.log('%c  1. Copy "Milk Mayhem.mp4" to /public/assets/', 'color: #6366f1');
      console.log('%c  2. Refresh the page', 'color: #6366f1');
      console.log('%c  See /SETUP_YOUR_MUSIC.md for details', 'color: #6366f1');
      setUsingChiptune(true);
      soundManager.initialize();
      if (autoPlay) {
        soundManager.playBackgroundMusic();
      }
      setIsInitialized(true);
      return;
    }

    // If we have a URL, try to use it
    if (audioUrl) {
      const success = backgroundMusicManager.initialize(audioUrl);
      if (!success && useChiptune) {
        // Fall back to chiptune if initialization failed
        console.log('Falling back to chiptune music');
        setUsingChiptune(true);
        soundManager.initialize();
        if (autoPlay) {
          soundManager.playBackgroundMusic();
        }
      } else if (success) {
        backgroundMusicManager.setVolume(volume / 100);
        if (autoPlay) {
          backgroundMusicManager.play();
        }
      }
      setIsInitialized(true);
    }

    // Add click listener to resume music on first user interaction
    const handleFirstInteraction = () => {
      if (autoPlay) {
        if (usingChiptune) {
          soundManager.playBackgroundMusic();
        } else if (!backgroundMusicManager.isMusicPlaying()) {
          backgroundMusicManager.resume();
        }
      }
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('keydown', handleFirstInteraction);
    };

    document.addEventListener('click', handleFirstInteraction);
    document.addEventListener('keydown', handleFirstInteraction);

    return () => {
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('keydown', handleFirstInteraction);
    };
  }, [audioUrl, autoPlay, useChiptune]);

  const handleToggleMute = () => {
    if (usingChiptune) {
      if (isMuted) {
        soundManager.playBackgroundMusic();
      } else {
        soundManager.stopBackgroundMusic();
      }
      setIsMuted(!isMuted);
    } else {
      const muted = backgroundMusicManager.toggleMute();
      setIsMuted(muted);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    
    if (!usingChiptune) {
      backgroundMusicManager.setVolume(newVolume / 100);
      
      // Unmute if volume is changed
      if (isMuted && newVolume > 0) {
        setIsMuted(false);
        backgroundMusicManager.setMuted(false);
      }
    } else {
      // For chiptune, we can't adjust volume dynamically, but we can track it
      if (isMuted && newVolume > 0) {
        setIsMuted(false);
        soundManager.playBackgroundMusic();
      }
    }
  };

  if (!isInitialized) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-purple-900/80 backdrop-blur-sm border-2 border-purple-400 rounded-lg p-3 flex items-center gap-3 shadow-lg">
      <Button
        onClick={handleToggleMute}
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-white hover:bg-purple-700"
        title={isMuted ? 'Unmute music' : 'Mute music'}
      >
        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
      </Button>
      
      <div className="flex items-center gap-2 min-w-[120px]">
        <Slider
          value={[isMuted ? 0 : volume]}
          onValueChange={handleVolumeChange}
          max={100}
          step={1}
          className="w-full"
          disabled={usingChiptune}
          title={usingChiptune ? 'Volume control not available for chiptune music' : 'Adjust volume'}
        />
        <span className="text-xs text-white min-w-[3ch]">{Math.round(isMuted ? 0 : volume)}</span>
      </div>

      <span 
        className="text-xs text-purple-300 hidden sm:block cursor-help"
        title={usingChiptune ? 'Chiptune mode - Copy Milk Mayhem.mp4 to /public/assets/ folder to use your custom music!' : 'Custom background music playing'}
      >
        {usingChiptune ? '🎮' : '🎵'}
      </span>
    </div>
  );
}
