import { useState, useEffect } from 'react';
import { AlertTriangle, Check, Loader2, X } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface EdgeFunctionCheckProps {
  onStatusChange?: (isAvailable: boolean) => void;
}

export function EdgeFunctionCheck({ onStatusChange }: EdgeFunctionCheckProps) {
  const [status, setStatus] = useState<'checking' | 'available' | 'unavailable'>('checking');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    checkEdgeFunction();
  }, []);

  const checkEdgeFunction = async () => {
    setStatus('checking');
    setError('');

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server/health`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.status === 'ok') {
          setStatus('available');
          onStatusChange?.(true);
        } else {
          setStatus('unavailable');
          setError('Edge Function responded but with unexpected status');
          onStatusChange?.(false);
        }
      } else {
        setStatus('unavailable');
        setError(`Server returned ${response.status}`);
        onStatusChange?.(false);
      }
    } catch (error: any) {
      setStatus('unavailable');
      if (error instanceof TypeError && error.message.includes('fetch')) {
        setError('Cannot connect to server - Edge Function may not be deployed');
      } else {
        setError(error.message || 'Unknown error');
      }
      onStatusChange?.(false);
    }
  };

  if (status === 'checking') {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-600">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Checking multiplayer server...</span>
      </div>
    );
  }

  if (status === 'available') {
    return (
      <div className="flex items-center gap-2 text-sm text-green-600">
        <Check className="w-4 h-4" />
        <span>Multiplayer server online</span>
      </div>
    );
  }

  return (
    <div className="p-4 bg-yellow-50 border-2 border-yellow-300 rounded-xl">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h3 className="font-bold text-yellow-900 mb-1">Using Local Mode</h3>
          <p className="text-sm text-yellow-800 mb-2">
            ⚠️ Multiplayer server not deployed. You can test locally, but players must be in the same browser.
          </p>
          {error && (
            <p className="text-xs text-yellow-700 mb-2 font-mono bg-yellow-100 p-2 rounded">
              {error}
            </p>
          )}
          <div className="space-y-2 text-sm text-yellow-900">
            <p className="font-bold">✅ Current Status:</p>
            <ul className="list-none space-y-1 ml-2 text-xs">
              <li>✓ Can create/join games</li>
              <li>✓ Can test multiplayer features</li>
              <li>✗ No real online multiplayer</li>
              <li>✗ Players need same browser tab</li>
            </ul>
            
            <p className="font-bold mt-3">🚀 Deploy in 5 minutes:</p>
            <ol className="list-decimal list-inside space-y-1 ml-2 text-xs">
              <li>Install: <code className="bg-yellow-100 px-1 rounded text-[10px]">npm install -g supabase</code></li>
              <li>Login: <code className="bg-yellow-100 px-1 rounded text-[10px]">supabase login</code></li>
              <li>Deploy: <code className="bg-yellow-100 px-1 rounded text-[10px]">supabase functions deploy make-server</code></li>
            </ol>
            <p className="mt-2 text-xs">
              📖 Full guide: <strong>DEPLOY_MULTIPLAYER.md</strong>
            </p>
          </div>
          <div className="flex gap-2 mt-3">
            <button
              onClick={checkEdgeFunction}
              className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors text-sm"
            >
              Check Again
            </button>
            <button
              onClick={() => onStatusChange?.(true)}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
            >
              Continue in Local Mode
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
