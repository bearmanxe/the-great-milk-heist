import { Hono } from 'npm:hono';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Helper to get enemy multiplier based on player count
function getEnemyMultiplier(playerCount: number): number {
  switch (playerCount) {
    case 1: return 1;
    case 2: return 2;
    case 3: return 2.5;
    case 4: return 3;
    default: return 1;
  }
}

// Create a new multiplayer session
app.post('/create-session', async (c) => {
  try {
    const { session, hostPlayer } = await c.req.json();
    
    // Store session
    await kv.set(`mp_session:${session.id}`, session);
    
    // Store host player
    await kv.set(`mp_player:${session.id}:${hostPlayer.id}`, hostPlayer);
    
    // Store player list
    await kv.set(`mp_players:${session.id}`, [hostPlayer.id]);
    
    return c.json({ success: true, session });
  } catch (error) {
    console.error('Error creating session:', error);
    return c.text('Failed to create session', 500);
  }
});

// Join an existing session
app.post('/join-session', async (c) => {
  try {
    const { sessionId, player } = await c.req.json();
    
    // Get session
    const session = await kv.get(`mp_session:${sessionId}`);
    if (!session) {
      return c.text('Session not found', 404);
    }
    
    // Check if session is full
    if (session.playerCount >= session.maxPlayers) {
      return c.text('Session is full', 400);
    }
    
    // Check if game already started
    if (session.status === 'playing') {
      return c.text('Game already started', 400);
    }
    
    // Get current players
    const playerIds = await kv.get(`mp_players:${sessionId}`) || [];
    
    // Check if player already in session
    if (playerIds.includes(player.id)) {
      return c.text('Already in session', 400);
    }
    
    // Add player
    playerIds.push(player.id);
    await kv.set(`mp_players:${sessionId}`, playerIds);
    await kv.set(`mp_player:${sessionId}:${player.id}`, player);
    
    // Update session player count
    session.playerCount = playerIds.length;
    await kv.set(`mp_session:${sessionId}`, session);
    
    return c.json(session);
  } catch (error) {
    console.error('Error joining session:', error);
    return c.text('Failed to join session', 500);
  }
});

// Player heartbeat to keep them active
app.post('/heartbeat', async (c) => {
  try {
    const { sessionId, playerId, player } = await c.req.json();
    
    // Update player data with timestamp
    const playerData = {
      ...player,
      lastUpdate: Date.now()
    };
    await kv.set(`mp_player:${sessionId}:${playerId}`, playerData);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error in heartbeat:', error);
    return c.text('Failed to update heartbeat', 500);
  }
});

// Leave session
app.post('/leave-session', async (c) => {
  try {
    const { sessionId, playerId } = await c.req.json();
    
    // Get session
    const session = await kv.get(`mp_session:${sessionId}`);
    if (!session) {
      return c.json({ success: true }); // Already gone
    }
    
    // Remove player
    const playerIds = await kv.get(`mp_players:${sessionId}`) || [];
    const updatedPlayerIds = playerIds.filter((id: string) => id !== playerId);
    
    // Delete player data
    await kv.del(`mp_player:${sessionId}:${playerId}`);
    
    if (updatedPlayerIds.length === 0) {
      // No players left, delete session
      await kv.del(`mp_session:${sessionId}`);
      await kv.del(`mp_players:${sessionId}`);
    } else {
      // Update player list and count
      await kv.set(`mp_players:${sessionId}`, updatedPlayerIds);
      session.playerCount = updatedPlayerIds.length;
      
      // If host left, assign new host
      if (session.hostId === playerId) {
        session.hostId = updatedPlayerIds[0];
      }
      
      await kv.set(`mp_session:${sessionId}`, session);
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error leaving session:', error);
    return c.text('Failed to leave session', 500);
  }
});

// Get session info
app.get('/session/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const session = await kv.get(`mp_session:${sessionId}`);
    
    if (!session) {
      return c.text('Session not found', 404);
    }
    
    return c.json(session);
  } catch (error) {
    console.error('Error getting session:', error);
    return c.text('Failed to get session', 500);
  }
});

// Get all players in session
app.get('/session/:sessionId/players', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const playerIds = await kv.get(`mp_players:${sessionId}`) || [];
    
    const players = [];
    for (const playerId of playerIds) {
      const player = await kv.get(`mp_player:${sessionId}:${playerId}`);
      if (player) {
        players.push(player);
      }
    }
    
    return c.json(players);
  } catch (error) {
    console.error('Error getting players:', error);
    return c.text('Failed to get players', 500);
  }
});

// Update session settings (host only)
app.post('/update-settings', async (c) => {
  try {
    const { sessionId, hostId, difficulty, gameMode } = await c.req.json();
    
    const session = await kv.get(`mp_session:${sessionId}`);
    if (!session) {
      return c.text('Session not found', 404);
    }
    
    if (session.hostId !== hostId) {
      return c.text('Only host can update settings', 403);
    }
    
    // Update settings
    session.difficulty = difficulty;
    session.gameMode = gameMode;
    await kv.set(`mp_session:${sessionId}`, session);
    
    return c.json(session);
  } catch (error) {
    console.error('Error updating settings:', error);
    return c.text('Failed to update settings', 500);
  }
});

// Start game (host only)
app.post('/start-game', async (c) => {
  try {
    const { sessionId, hostId } = await c.req.json();
    
    const session = await kv.get(`mp_session:${sessionId}`);
    if (!session) {
      return c.text('Session not found', 404);
    }
    
    if (session.hostId !== hostId) {
      return c.text('Only host can start game', 403);
    }
    
    session.status = 'playing';
    await kv.set(`mp_session:${sessionId}`, session);
    
    return c.json({ success: true, enemyMultiplier: getEnemyMultiplier(session.playerCount) });
  } catch (error) {
    console.error('Error starting game:', error);
    return c.text('Failed to start game', 500);
  }
});

export default app;
