-- FIX FOR TRIGGER NOT WORKING
-- Run this if the main migration's trigger isn't creating user profiles

-- First, drop the existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Recreate the function with better error handling and logging
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  username_to_use TEXT;
  error_message TEXT;
BEGIN
  -- Log the trigger execution (for debugging)
  RAISE NOTICE 'Trigger fired for user: %', NEW.id;
  
  -- Get username from metadata or generate a fallback
  username_to_use := COALESCE(
    NEW.raw_user_meta_data->>'username', 
    'Player_' || substr(NEW.id::text, 1, 8)
  );
  
  RAISE NOTICE 'Using username: %', username_to_use;
  
  -- Insert user profile
  INSERT INTO public.users (
    id, 
    username, 
    unlocked_cosmetics, 
    weapon_upgrades, 
    achievements, 
    total_coins, 
    selected_cosmetic, 
    stats, 
    friends
  )
  VALUES (
    NEW.id,
    username_to_use,
    ARRAY['default']::TEXT[],
    '{\"damage\": 0, \"attackSpeed\": 0, \"range\": 0, \"knockback\": 0}'::JSONB,
    ARRAY[]::TEXT[],
    0,
    '🧑',
    '{\"roomsCleared\": 0, \"enemiesKilled\": 0, \"bossesDefeated\": 0, \"coinsEarned\": 0, \"hasWonOnce\": false}'::JSONB,
    ARRAY[]::UUID[]
  );
  
  RAISE NOTICE 'User profile created successfully for: %', NEW.id;
  
  RETURN NEW;
  
EXCEPTION
  WHEN unique_violation THEN
    -- If username is taken, append user ID
    RAISE NOTICE 'Username conflict, trying with suffix';
    INSERT INTO public.users (
      id, 
      username, 
      unlocked_cosmetics, 
      weapon_upgrades, 
      achievements, 
      total_coins, 
      selected_cosmetic, 
      stats, 
      friends
    )
    VALUES (
      NEW.id,
      username_to_use || '_' || substr(NEW.id::text, 1, 4),
      ARRAY['default']::TEXT[],
      '{\"damage\": 0, \"attackSpeed\": 0, \"range\": 0, \"knockback\": 0}'::JSONB,
      ARRAY[]::TEXT[],
      0,
      '🧑',
      '{\"roomsCleared\": 0, \"enemiesKilled\": 0, \"bossesDefeated\": 0, \"coinsEarned\": 0, \"hasWonOnce\": false}'::JSONB,
      ARRAY[]::UUID[]
    );
    RETURN NEW;
    
  WHEN OTHERS THEN
    -- Log any other errors
    GET STACKED DIAGNOSTICS error_message = MESSAGE_TEXT;
    RAISE WARNING 'Error in handle_new_user: %', error_message;
    -- Still return NEW to not block auth user creation
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Grant execute permission to Supabase service role
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;

-- Recreate the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW 
  EXECUTE FUNCTION public.handle_new_user();

-- Verify the trigger was created
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_auth_user_created'
  ) THEN
    RAISE NOTICE '✓ Trigger created successfully';
  ELSE
    RAISE WARNING '✗ Trigger was NOT created';
  END IF;
END $$;
