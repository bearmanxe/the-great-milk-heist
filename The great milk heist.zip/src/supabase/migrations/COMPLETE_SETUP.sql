-- ========================================
-- 🥛 THE GREAT MILK HEIST - COMPLETE SETUP 🥛
-- ========================================
-- 
-- ⚠️ YOU MUST RUN THIS BEFORE THE GAME WILL WORK! ⚠️
--
-- INSTRUCTIONS:
-- 1. Select ALL of this file (Ctrl+A)
-- 2. Copy it (Ctrl+C)
-- 3. Go to: https://supabase.com/dashboard/project/symyhtogzjmuibiayvnr/sql
-- 4. Paste (Ctrl+V) and click "Run" (or Ctrl+Enter)
-- 5. Wait for "Success" message
-- 6. Refresh the game page
--
-- What this does:
-- ✅ Creates all tables (users, friend_requests, session_invites)
-- ✅ Sets up Row Level Security (RLS) policies
-- ✅ Creates the auto-user-creation trigger (CRITICAL!)
-- ✅ Creates the fallback RPC function (CRITICAL!)
-- ✅ Runs a test to verify everything works
--
-- ⏱️ Time required: ~30 seconds
-- 
-- This is a ONE-TIME setup. You only need to run this once!
-- ========================================

-- Clean up any existing objects (optional - only if you're resetting)
-- UNCOMMENT these lines if you want to start completely fresh:
-- DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
-- DROP FUNCTION IF EXISTS public.handle_new_user();
-- DROP FUNCTION IF EXISTS public.create_user_profile(UUID, TEXT);
-- DROP FUNCTION IF EXISTS clean_old_session_invites();
-- DROP TABLE IF EXISTS public.session_invites CASCADE;
-- DROP TABLE IF EXISTS public.friend_requests CASCADE;
-- DROP TABLE IF EXISTS public.users CASCADE;

RAISE NOTICE '========================================';
RAISE NOTICE 'Starting Complete Setup...';
RAISE NOTICE '========================================';

-- ========================================
-- STEP 1: CREATE TABLES
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 1: Creating tables...';

-- Create users table
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  unlocked_cosmetics TEXT[] DEFAULT ARRAY['default']::TEXT[],
  weapon_upgrades JSONB DEFAULT '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
  achievements TEXT[] DEFAULT ARRAY[]::TEXT[],
  total_coins INTEGER DEFAULT 0,
  selected_cosmetic TEXT DEFAULT '🧑',
  stats JSONB DEFAULT '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
  friends UUID[] DEFAULT ARRAY[]::UUID[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create friend_requests table
CREATE TABLE IF NOT EXISTS public.friend_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  from_username TEXT NOT NULL,
  to_user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at BIGINT NOT NULL
);

-- Create session_invites table
CREATE TABLE IF NOT EXISTS public.session_invites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id TEXT NOT NULL,
  friend_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  inviter_name TEXT NOT NULL,
  created_at BIGINT NOT NULL
);

RAISE NOTICE '✓ Tables created';

-- ========================================
-- STEP 2: CREATE INDEXES
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 2: Creating indexes...';

CREATE INDEX IF NOT EXISTS idx_users_username ON public.users(username);
CREATE INDEX IF NOT EXISTS idx_friend_requests_to_user ON public.friend_requests(to_user_id) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_session_invites_friend ON public.session_invites(friend_id);

RAISE NOTICE '✓ Indexes created';

-- ========================================
-- STEP 3: ENABLE RLS
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 3: Enabling Row Level Security...';

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.friend_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_invites ENABLE ROW LEVEL SECURITY;

RAISE NOTICE '✓ RLS enabled';

-- ========================================
-- STEP 4: CREATE RLS POLICIES
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 4: Creating RLS policies...';

-- Users table policies
DROP POLICY IF EXISTS "Users can read their own data" ON public.users;
CREATE POLICY "Users can read their own data" ON public.users
  FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update their own data" ON public.users;
CREATE POLICY "Users can update their own data" ON public.users
  FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert their own data" ON public.users;
CREATE POLICY "Users can insert their own data" ON public.users
  FOR INSERT WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Users can read other users' basic info" ON public.users;
CREATE POLICY "Users can read other users' basic info" ON public.users
  FOR SELECT USING (true);

-- Friend requests policies
DROP POLICY IF EXISTS "Users can read their own friend requests" ON public.friend_requests;
CREATE POLICY "Users can read their own friend requests" ON public.friend_requests
  FOR SELECT USING (auth.uid() = from_user_id OR auth.uid() = to_user_id);

DROP POLICY IF EXISTS "Users can create friend requests" ON public.friend_requests;
CREATE POLICY "Users can create friend requests" ON public.friend_requests
  FOR INSERT WITH CHECK (auth.uid() = from_user_id);

DROP POLICY IF EXISTS "Users can update their received friend requests" ON public.friend_requests;
CREATE POLICY "Users can update their received friend requests" ON public.friend_requests
  FOR UPDATE USING (auth.uid() = to_user_id);

-- Session invites policies
DROP POLICY IF EXISTS "Users can read their own invites" ON public.session_invites;
CREATE POLICY "Users can read their own invites" ON public.session_invites
  FOR SELECT USING (auth.uid() = friend_id);

DROP POLICY IF EXISTS "Users can create invites" ON public.session_invites;
CREATE POLICY "Users can create invites" ON public.session_invites
  FOR INSERT WITH CHECK (true);

RAISE NOTICE '✓ RLS policies created';

-- ========================================
-- STEP 5: CREATE TRIGGER FUNCTION
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 5: Creating auto-user-creation trigger...';

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  username_to_use TEXT;
BEGIN
  username_to_use := COALESCE(
    NEW.raw_user_meta_data->>'username', 
    'Player_' || substr(NEW.id::text, 1, 8)
  );
  
  INSERT INTO public.users (
    id, username, unlocked_cosmetics, weapon_upgrades, achievements, 
    total_coins, selected_cosmetic, stats, friends
  )
  VALUES (
    NEW.id,
    username_to_use,
    ARRAY['default']::TEXT[],
    '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
    ARRAY[]::TEXT[],
    0,
    '🧑',
    '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
    ARRAY[]::UUID[]
  );
  
  RETURN NEW;
  
EXCEPTION
  WHEN unique_violation THEN
    INSERT INTO public.users (
      id, username, unlocked_cosmetics, weapon_upgrades, achievements, 
      total_coins, selected_cosmetic, stats, friends
    )
    VALUES (
      NEW.id,
      username_to_use || '_' || substr(NEW.id::text, 1, 4),
      ARRAY['default']::TEXT[],
      '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
      ARRAY[]::TEXT[],
      0,
      '🧑',
      '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
      ARRAY[]::UUID[]
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Grant permissions
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;

-- Create trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW 
  EXECUTE FUNCTION public.handle_new_user();

RAISE NOTICE '✓ Trigger created';

-- ========================================
-- STEP 6: CREATE FALLBACK RPC FUNCTION
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 6: Creating fallback RPC function...';

CREATE OR REPLACE FUNCTION public.create_user_profile(
  user_id UUID,
  user_name TEXT
)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.users WHERE id = user_id) THEN
    RETURN jsonb_build_object(
      'success', true,
      'message', 'User profile already exists'
    );
  END IF;
  
  INSERT INTO public.users (
    id, username, unlocked_cosmetics, weapon_upgrades, achievements, 
    total_coins, selected_cosmetic, stats, friends
  )
  VALUES (
    user_id, user_name,
    ARRAY['default']::TEXT[],
    '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
    ARRAY[]::TEXT[], 0, '🧑',
    '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
    ARRAY[]::UUID[]
  );
  
  RETURN jsonb_build_object('success', true, 'message', 'User profile created');
  
EXCEPTION
  WHEN unique_violation THEN
    INSERT INTO public.users (
      id, username, unlocked_cosmetics, weapon_upgrades, achievements, 
      total_coins, selected_cosmetic, stats, friends
    )
    VALUES (
      user_id, user_name || '_' || substr(user_id::text, 1, 4),
      ARRAY['default']::TEXT[],
      '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
      ARRAY[]::TEXT[], 0, '🧑',
      '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
      ARRAY[]::UUID[]
    );
    RETURN jsonb_build_object('success', true, 'message', 'Profile created with modified username');
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION public.create_user_profile(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_user_profile(UUID, TEXT) TO anon;

RAISE NOTICE '✓ Fallback function created';

-- ========================================
-- STEP 7: CREATE CLEANUP FUNCTION
-- ========================================

RAISE NOTICE '';
RAISE NOTICE 'Step 7: Creating session cleanup function...';

CREATE OR REPLACE FUNCTION clean_old_session_invites()
RETURNS void AS $$
BEGIN
  DELETE FROM public.session_invites
  WHERE created_at < (EXTRACT(EPOCH FROM NOW()) * 1000)::BIGINT - 300000;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

RAISE NOTICE '✓ Cleanup function created';

-- ========================================
-- FINAL VERIFICATION
-- ========================================

RAISE NOTICE '';
RAISE NOTICE '========================================';
RAISE NOTICE 'SETUP COMPLETE!';
RAISE NOTICE '========================================';
RAISE NOTICE '';
RAISE NOTICE 'Created:';
RAISE NOTICE '  ✓ 3 tables (users, friend_requests, session_invites)';
RAISE NOTICE '  ✓ RLS policies for data security';
RAISE NOTICE '  ✓ Auto-user-creation trigger';
RAISE NOTICE '  ✓ Fallback RPC function';
RAISE NOTICE '  ✓ Session cleanup function';
RAISE NOTICE '';
RAISE NOTICE 'Next steps:';
RAISE NOTICE '  1. Disable email confirmation:';
RAISE NOTICE '     Authentication → Providers → Email → Toggle OFF';
RAISE NOTICE '  2. (Optional) Run test_complete_setup.sql to verify';
RAISE NOTICE '  3. Try signing up in the game!';
RAISE NOTICE '';
RAISE NOTICE 'If you have issues, run diagnostic_check.sql';
RAISE NOTICE '========================================';
