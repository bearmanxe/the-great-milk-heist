# 🚀 Database Setup Instructions

## Quick Start (30 seconds)

**You MUST run the migration before the game will work!**

### Steps:

1. **Open** `/supabase/migrations/COMPLETE_SETUP.sql` (this file)
2. **Copy** the entire contents
3. **Go to** https://supabase.com/dashboard/project/symyhtogzjmuibiayvnr/sql
4. **Paste** the SQL and click **"Run"**
5. **Refresh** the game page

---

## What This Does

The `COMPLETE_SETUP.sql` file creates:

✅ **Tables** - users, friend_requests, session_invites  
✅ **Trigger** - Automatically creates user profiles when someone signs up  
✅ **RPC Function** - Fallback method to create profiles if trigger fails  
✅ **Security** - Row Level Security (RLS) policies  
✅ **Indexes** - For better performance  

---

## Troubleshooting

### Error: "Could not find the function public.create_user_profile"

**Solution:** You haven't run the migration yet. Follow the steps above.

### Error: "The result contains 0 rows"

**Solution:** The trigger isn't working. Run `COMPLETE_SETUP.sql` again.

### Still Having Issues?

1. Open `/supabase/migrations/diagnostic_check.sql`
2. Run it in Supabase SQL Editor
3. Check the output for issues
4. See `/TROUBLESHOOTING.md` for detailed help

---

## Files in This Folder

- **COMPLETE_SETUP.sql** ← **START HERE! Run this first!**
- diagnostic_check.sql - Check if everything is set up correctly
- test_complete_setup.sql - Test the setup
- 20250107000000_initial_schema.sql - Initial schema (legacy)
- 20250107000001_fix_trigger.sql - Trigger fix (legacy)
- create_user_profile_function.sql - RPC function (legacy)
- manual_user_creation.sql - Manual user creation (for debugging)
- reset_and_reapply.sql - Reset everything and start over

---

## Need Help?

Check these files:
- `/START_HERE.md` - Overview of the game
- `/SUPABASE_SETUP.md` - Detailed Supabase setup guide
- `/TROUBLESHOOTING.md` - Common issues and solutions
- `/AUTH_REFERENCE.md` - Authentication system details

---

**⚡ Remember: Run COMPLETE_SETUP.sql before playing the game!**
