-- MANUAL USER CREATION SCRIPT
-- Use this ONLY if the database trigger isn't working and you need to manually create a user profile
-- 
-- Instructions:
-- 1. Go to Supabase Dashboard → Authentication → Users
-- 2. Find your user and copy the UUID (e.g., '12345678-1234-1234-1234-123456789abc')
-- 3. Replace 'YOUR_USER_ID' below with your actual UUID
-- 4. Replace 'YourUsername' with your desired username
-- 5. Run this in SQL Editor

-- IMPORTANT: Only run this if:
-- - You've created an account (visible in Authentication → Users)
-- - But your user data isn't in the users table (Table Editor → users)
-- - The trigger isn't working (verified in Database → Triggers)

INSERT INTO public.users (
  id, 
  username, 
  unlocked_cosmetics, 
  weapon_upgrades, 
  achievements, 
  total_coins, 
  selected_cosmetic, 
  stats, 
  friends
)
VALUES (
  'YOUR_USER_ID',  -- Replace with your actual user UUID from Authentication
  'YourUsername',  -- Replace with your desired username
  ARRAY['default']::TEXT[],
  '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
  ARRAY[]::TEXT[],
  0,
  '🧑',
  '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
  ARRAY[]::UUID[]
)
ON CONFLICT (id) DO NOTHING;  -- Won't create duplicate if already exists

-- After running this, try logging in again with your email and password
