-- DIAGNOSTIC CHECK SCRIPT
-- Run this to verify your Supabase setup is correct
-- Copy the output and check for any issues

-- 1. Check if tables exist
SELECT 
  'Tables Check' as test_name,
  CASE 
    WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users' AND table_schema = 'public') THEN '✓ users table exists'
    ELSE '✗ users table MISSING'
  END as users_table,
  CASE 
    WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'friend_requests' AND table_schema = 'public') THEN '✓ friend_requests table exists'
    ELSE '✗ friend_requests table MISSING'
  END as friend_requests_table,
  CASE 
    WHEN EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'session_invites' AND table_schema = 'public') THEN '✓ session_invites table exists'
    ELSE '✗ session_invites table MISSING'
  END as session_invites_table;

-- 2. Check if trigger exists
SELECT 
  'Trigger Check' as test_name,
  CASE 
    WHEN EXISTS (
      SELECT 1 FROM pg_trigger 
      WHERE tgname = 'on_auth_user_created'
    ) THEN '✓ on_auth_user_created trigger exists'
    ELSE '✗ on_auth_user_created trigger MISSING - THIS IS THE PROBLEM!'
  END as trigger_status;

-- 3. Check if trigger function exists
SELECT 
  'Function Check' as test_name,
  CASE 
    WHEN EXISTS (
      SELECT 1 FROM pg_proc 
      WHERE proname = 'handle_new_user'
    ) THEN '✓ handle_new_user function exists'
    ELSE '✗ handle_new_user function MISSING'
  END as function_status;

-- 4. Check RLS policies
SELECT 
  'RLS Policies Check' as test_name,
  tablename,
  policyname,
  '✓ Policy exists' as status
FROM pg_policies 
WHERE schemaname = 'public' 
  AND tablename IN ('users', 'friend_requests', 'session_invites')
ORDER BY tablename, policyname;

-- 5. Count users
SELECT 
  'User Count' as test_name,
  COUNT(*) as total_users,
  CASE 
    WHEN COUNT(*) = 0 THEN 'No users yet (normal for new setup)'
    ELSE CONCAT(COUNT(*), ' user(s) in database')
  END as status
FROM public.users;

-- 6. Check for orphaned auth users (in auth.users but not in public.users)
SELECT 
  'Orphaned Users Check' as test_name,
  COUNT(*) as orphaned_count,
  CASE 
    WHEN COUNT(*) = 0 THEN '✓ No orphaned users (good)'
    ELSE '✗ Found users in auth.users but not in public.users - TRIGGER NOT WORKING!'
  END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE pu.id IS NULL;

-- 7. Show any orphaned users (if they exist)
SELECT 
  'Orphaned User Details' as info,
  au.id as user_id,
  au.email,
  au.raw_user_meta_data->>'username' as username_from_metadata,
  au.created_at as auth_created_at,
  'Run manual_user_creation.sql with this info' as action_required
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE pu.id IS NULL
LIMIT 10;

-- 8. Check trigger configuration
SELECT 
  'Trigger Configuration' as test_name,
  tgname as trigger_name,
  tgtype as trigger_type,
  tgenabled as is_enabled,
  CASE 
    WHEN tgenabled = 'O' THEN '✓ Trigger is enabled'
    WHEN tgenabled = 'D' THEN '✗ Trigger is DISABLED'
    ELSE '? Unknown status'
  END as status
FROM pg_trigger
WHERE tgname = 'on_auth_user_created';

-- INTERPRETATION:
-- ✓ = Good, everything is working
-- ✗ = Problem that needs to be fixed
-- 
-- If you see "trigger MISSING", run the full migration again
-- If you see "orphaned users", the trigger didn't work - use manual_user_creation.sql
