-- RESET AND REAPPLY MIGRATION
-- Run this if you're getting RLS errors after upgrading to the new auth system
-- WARNING: This will delete all existing user data!

-- Step 1: Drop all existing tables and triggers
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP TABLE IF EXISTS public.session_invites CASCADE;
DROP TABLE IF EXISTS public.friend_requests CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;

-- Step 2: Now run the main migration file
-- Go to: /supabase/migrations/20250107000000_initial_schema.sql
-- Copy its contents and run it in the SQL Editor

-- Or if you want to do it all at once, paste the contents of 
-- 20250107000000_initial_schema.sql here after these comments
