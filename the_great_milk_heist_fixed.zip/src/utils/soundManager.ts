class SoundManager {
  private audioContext: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private currentMusic: OscillatorNode[] = [];
  private musicVolume = 0.3;
  private sfxVolume = 0.4;

  initialize() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.musicGainNode = this.audioContext.createGain();
      this.musicGainNode.gain.value = this.musicVolume;
      this.musicGainNode.connect(this.audioContext.destination);

      this.sfxGainNode = this.audioContext.createGain();
      this.sfxGainNode.gain.value = this.sfxVolume;
      this.sfxGainNode.connect(this.audioContext.destination);
    }
  }

  playBackgroundMusic() {
    this.initialize();
    if (!this.audioContext || !this.musicGainNode) return;

    this.stopBackgroundMusic();

    // Create an energetic chiptune adventure melody
    const melody = [
      { freq: 523.25, duration: 0.15 }, // C5
      { freq: 659.25, duration: 0.15 }, // E5
      { freq: 783.99, duration: 0.15 }, // G5
      { freq: 880.00, duration: 0.15 }, // A5
      { freq: 783.99, duration: 0.15 }, // G5
      { freq: 659.25, duration: 0.15 }, // E5
      { freq: 698.46, duration: 0.3 },  // F5
      { freq: 659.25, duration: 0.15 }, // E5
      { freq: 523.25, duration: 0.15 }, // C5
      { freq: 587.33, duration: 0.15 }, // D5
      { freq: 659.25, duration: 0.3 },  // E5
    ];

    const bass = [
      { freq: 130.81, duration: 0.6 }, // C3
      { freq: 164.81, duration: 0.6 }, // E3
      { freq: 146.83, duration: 0.6 }, // D3
      { freq: 130.81, duration: 0.6 }, // C3
    ];

    let time = this.audioContext.currentTime;

    const playLoop = () => {
      if (!this.audioContext || !this.musicGainNode) return;

      this.currentMusic = [];
      time = this.audioContext.currentTime;

      // Play melody
      melody.forEach((note) => {
        const osc = this.audioContext!.createOscillator();
        const gainNode = this.audioContext!.createGain();

        osc.type = 'square';
        osc.frequency.value = note.freq;

        gainNode.gain.setValueAtTime(0.08, time);
        gainNode.gain.exponentialRampToValueAtTime(0.01, time + note.duration);

        osc.connect(gainNode);
        gainNode.connect(this.musicGainNode!);

        osc.start(time);
        osc.stop(time + note.duration);

        this.currentMusic.push(osc);

        time += note.duration;
      });

      // Play bass
      let bassTime = this.audioContext.currentTime;
      bass.forEach((note) => {
        const osc = this.audioContext!.createOscillator();
        const gainNode = this.audioContext!.createGain();

        osc.type = 'triangle';
        osc.frequency.value = note.freq;

        gainNode.gain.setValueAtTime(0.12, bassTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, bassTime + note.duration);

        osc.connect(gainNode);
        gainNode.connect(this.musicGainNode!);

        osc.start(bassTime);
        osc.stop(bassTime + note.duration);

        this.currentMusic.push(osc);

        bassTime += note.duration;
      });

      // Schedule next loop
      setTimeout(playLoop, melody.reduce((acc, n) => acc + n.duration, 0) * 1000);
    };

    playLoop();
  }

  stopBackgroundMusic() {
    this.currentMusic.forEach(osc => {
      try {
        osc.stop();
      } catch (e) {
        // Already stopped
      }
    });
    this.currentMusic = [];
  }

  playAttackSound() {
    this.initialize();
    if (!this.audioContext || !this.sfxGainNode) return;

    const osc = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(400, this.audioContext.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, this.audioContext.currentTime + 0.08);

    gainNode.gain.setValueAtTime(0.25, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.08);

    osc.connect(gainNode);
    gainNode.connect(this.sfxGainNode);

    osc.start();
    osc.stop(this.audioContext.currentTime + 0.08);
  }

  playHitSound() {
    this.initialize();
    if (!this.audioContext || !this.sfxGainNode) return;

    // Create impact with white noise burst
    const osc = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    osc.type = 'square';
    osc.frequency.setValueAtTime(200, this.audioContext.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, this.audioContext.currentTime + 0.12);

    gainNode.gain.setValueAtTime(0.35, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.12);

    osc.connect(gainNode);
    gainNode.connect(this.sfxGainNode);

    osc.start();
    osc.stop(this.audioContext.currentTime + 0.12);
  }

  playDeathSound() {
    this.initialize();
    if (!this.audioContext || !this.sfxGainNode) return;

    // Dramatic death sound with descending pitch
    const osc = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(300, this.audioContext.currentTime);
    osc.frequency.exponentialRampToValueAtTime(30, this.audioContext.currentTime + 0.4);

    gainNode.gain.setValueAtTime(0.45, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.4);

    osc.connect(gainNode);
    gainNode.connect(this.sfxGainNode);

    osc.start();
    osc.stop(this.audioContext.currentTime + 0.4);
  }

  playPowerUpSound() {
    this.initialize();
    if (!this.audioContext || !this.sfxGainNode) return;

    // Ascending magical power-up sound
    [0, 0.08, 0.16].forEach((delay) => {
      const osc = this.audioContext!.createOscillator();
      const gainNode = this.audioContext!.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(500 + delay * 600, this.audioContext!.currentTime + delay);
      osc.frequency.exponentialRampToValueAtTime(900 + delay * 600, this.audioContext!.currentTime + delay + 0.15);

      gainNode.gain.setValueAtTime(0.25, this.audioContext!.currentTime + delay);
      gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext!.currentTime + delay + 0.25);

      osc.connect(gainNode);
      gainNode.connect(this.sfxGainNode!);

      osc.start(this.audioContext!.currentTime + delay);
      osc.stop(this.audioContext!.currentTime + delay + 0.25);
    });
  }

  playRoomClearSound() {
    this.initialize();
    if (!this.audioContext || !this.sfxGainNode) return;

    // Triumphant victory fanfare
    const notes = [523.25, 659.25, 783.99, 1046.50, 1318.51]; // C-E-G-C-E arpeggio

    notes.forEach((freq, index) => {
      const osc = this.audioContext!.createOscillator();
      const gainNode = this.audioContext!.createGain();

      osc.type = 'sine';
      osc.frequency.value = freq;

      const startTime = this.audioContext!.currentTime + index * 0.08;
      gainNode.gain.setValueAtTime(0.35, startTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.4);

      osc.connect(gainNode);
      gainNode.connect(this.sfxGainNode!);

      osc.start(startTime);
      osc.stop(startTime + 0.4);
    });
  }

  playBossMusic() {
    this.initialize();
    if (!this.audioContext || !this.musicGainNode) return;

    this.stopBackgroundMusic();

    // Epic intense boss battle music
    const bassLine = [
      { freq: 110.00, duration: 0.12 }, // A2
      { freq: 110.00, duration: 0.12 }, // A2
      { freq: 146.83, duration: 0.12 }, // D3
      { freq: 110.00, duration: 0.12 }, // A2
      { freq: 123.47, duration: 0.12 }, // B2
      { freq: 123.47, duration: 0.12 }, // B2
      { freq: 164.81, duration: 0.12 }, // E3
      { freq: 123.47, duration: 0.12 }, // B2
    ];

    const lead = [
      { freq: 440.00, duration: 0.24 }, // A4
      { freq: 493.88, duration: 0.24 }, // B4
      { freq: 523.25, duration: 0.24 }, // C5
      { freq: 493.88, duration: 0.24 }, // B4
    ];

    let time = this.audioContext.currentTime;

    const playLoop = () => {
      if (!this.audioContext || !this.musicGainNode) return;

      this.currentMusic = [];
      time = this.audioContext.currentTime;

      // Aggressive bass
      bassLine.forEach((note) => {
        const osc = this.audioContext!.createOscillator();
        const gainNode = this.audioContext!.createGain();

        osc.type = 'sawtooth';
        osc.frequency.value = note.freq;

        gainNode.gain.setValueAtTime(0.18, time);
        gainNode.gain.exponentialRampToValueAtTime(0.01, time + note.duration);

        osc.connect(gainNode);
        gainNode.connect(this.musicGainNode!);

        osc.start(time);
        osc.stop(time + note.duration);

        this.currentMusic.push(osc);

        time += note.duration;
      });

      // Lead melody
      let leadTime = this.audioContext.currentTime;
      lead.forEach((note) => {
        const osc = this.audioContext!.createOscillator();
        const gainNode = this.audioContext!.createGain();

        osc.type = 'square';
        osc.frequency.value = note.freq;

        gainNode.gain.setValueAtTime(0.1, leadTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, leadTime + note.duration);

        osc.connect(gainNode);
        gainNode.connect(this.musicGainNode!);

        osc.start(leadTime);
        osc.stop(leadTime + note.duration);

        this.currentMusic.push(osc);

        leadTime += note.duration;
      });

      setTimeout(playLoop, bassLine.reduce((acc, n) => acc + n.duration, 0) * 1000);
    };

    playLoop();
  }
}

export const soundManager = new SoundManager();
