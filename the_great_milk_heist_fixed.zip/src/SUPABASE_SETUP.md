# Supabase Database Setup Instructions

## Current Issue
The database tables haven't been created yet. You're seeing the error:
```
Could not find the table 'public.users' in the schema cache
```

## Important: Disable Email Confirmation

Since this game uses real email addresses but doesn't require email confirmation, you need to configure Supabase to skip email verification:

1. Go to your Supabase Dashboard: https://supabase.com/dashboard/project/symyhtogzjmuibiayvnr
2. Navigate to **Authentication** > **Providers** in the left sidebar
3. Click on **Email** provider
4. Scroll down to find **"Confirm email"**
5. Toggle it **OFF** (disable it)
6. Click **Save**

This allows users to sign up and immediately start playing without needing to verify their email.

## How to Apply the Migration

You have two options to set up your database:

### Option 1: Using Supabase Dashboard (Easiest)

1. Go to your Supabase Dashboard: https://supabase.com/dashboard/project/symyhtogzjmuibiayvnr
2. Click on "SQL Editor" in the left sidebar
3. Click "+ New query"
4. Copy the entire contents of `/supabase/migrations/20250107000000_initial_schema.sql`
5. Paste it into the SQL Editor
6. Click "Run" to execute the migration
7. Refresh your app and try signing up again

### Option 2: Using Supabase CLI (For Advanced Users)

If you have the Supabase CLI installed:

```bash
# Link to your project
supabase link --project-ref symyhtogzjmuibiayvnr

# Apply migrations
supabase db push

# Or apply a specific migration
supabase migration up
```

## What This Migration Creates

The migration creates three tables:

1. **users** - Stores user profiles, unlocked cosmetics, weapon upgrades, achievements, stats, and friends
2. **friend_requests** - Manages friend request system (pending, accepted, rejected)
3. **session_invites** - Handles multiplayer session invitations

It also sets up:
- **Row Level Security (RLS)** policies for data access control
- **Indexes** for better query performance
- **Automatic user profile creation** - A database trigger that automatically creates a user profile in the `users` table whenever someone signs up
- **Session cleanup function** - A function to clean up old session invites

## How User Creation Works

When someone signs up:
1. User provides email, username, and password
2. Supabase creates an authentication record
3. **Database trigger fires automatically** (happens in the background)
4. Trigger creates user profile in `users` table
5. App waits briefly and retries loading the data (handles any race conditions)
6. User is logged in and can start playing

**Note:** The app has built-in retry logic that waits up to 7.5 seconds for the trigger to complete, so you shouldn't see any "user not found" errors during signup.

## Verify Setup

After applying the migration, you can verify it worked by:

### Option A: Quick Visual Check
1. Going to "Table Editor" in your Supabase Dashboard
2. You should see three tables: `users`, `friend_requests`, and `session_invites`
3. Going to "Database" > "Triggers" - you should see a trigger called `on_auth_user_created`
4. Try creating an account in the game - it should work without errors

### Option B: Run Diagnostic Script (Recommended)
1. Go to SQL Editor in your Supabase Dashboard
2. Copy the contents of `/supabase/migrations/diagnostic_check.sql`
3. Paste and run in SQL Editor
4. Check the results:
   - All ✓ marks = Everything is working correctly
   - Any ✗ marks = Follow the instructions in the output

The diagnostic will tell you:
- If tables are created
- If the trigger exists
- If there are orphaned users (users in auth but not in the users table)
- What to do to fix any issues

## If You Already Applied the Old Migration

If you previously ran the migration and are getting RLS errors, you need to reapply it:

1. Go to SQL Editor in your Supabase Dashboard
2. Delete the old tables (this will delete any existing data):
   ```sql
   DROP TABLE IF EXISTS public.session_invites CASCADE;
   DROP TABLE IF EXISTS public.friend_requests CASCADE;
   DROP TABLE IF EXISTS public.users CASCADE;
   ```
3. Run the updated migration from `/supabase/migrations/20250107000000_initial_schema.sql`
4. Try signing up again - the user profile will be created automatically

## Need Help?

If you encounter any issues:
1. **See TROUBLESHOOTING.md** for common problems and solutions
2. Check the Supabase logs in the Dashboard under "Logs" > "Postgres Logs"
3. Make sure your Supabase project is not paused (free tier projects auto-pause after inactivity)
4. Verify the project ID matches: `symyhtogzjmuibiayvnr`
5. Check that the trigger exists: Database > Triggers > `on_auth_user_created`

**Common Issues:**
- ❌ RLS error → See TROUBLESHOOTING.md #1
- ❌ "Database not set up" → Follow Option 1 above
- ❌ "Confirm your email" → Disable email confirmation (see Important section)
- ❌ Can't sign in → Make sure you're using your EMAIL (not username) to log in
