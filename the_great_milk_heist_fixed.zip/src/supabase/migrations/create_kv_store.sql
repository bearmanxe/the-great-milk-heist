-- Create KV Store Table for Multiplayer Edge Function
-- Run this in Supabase SQL Editor before deploying the Edge Function

-- Create the key-value store table
CREATE TABLE IF NOT EXISTS kv_store_55cb4193 (
  key TEXT NOT NULL PRIMARY KEY,
  value JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add index for efficient prefix searches
CREATE INDEX IF NOT EXISTS idx_kv_store_prefix ON kv_store_55cb4193(key text_pattern_ops);

-- Add index for timestamp queries (useful for cleanup)
CREATE INDEX IF NOT EXISTS idx_kv_store_updated_at ON kv_store_55cb4193(updated_at);

-- Grant permissions to service role (Edge Functions use this)
GRANT ALL ON kv_store_55cb4193 TO service_role;
GRANT ALL ON kv_store_55cb4193 TO postgres;

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_kv_store_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS kv_store_updated_at_trigger ON kv_store_55cb4193;
CREATE TRIGGER kv_store_updated_at_trigger
  BEFORE UPDATE ON kv_store_55cb4193
  FOR EACH ROW
  EXECUTE FUNCTION update_kv_store_updated_at();

-- Verify table creation
DO $$
BEGIN
  IF EXISTS (
    SELECT FROM pg_tables
    WHERE schemaname = 'public'
    AND tablename = 'kv_store_55cb4193'
  ) THEN
    RAISE NOTICE '✅ Table kv_store_55cb4193 created successfully!';
  ELSE
    RAISE EXCEPTION '❌ Failed to create table kv_store_55cb4193';
  END IF;
END $$;

-- Display table info
SELECT 
  'kv_store_55cb4193' as table_name,
  COUNT(*) as row_count,
  pg_size_pretty(pg_total_relation_size('kv_store_55cb4193')) as total_size
FROM kv_store_55cb4193;

COMMENT ON TABLE kv_store_55cb4193 IS 'Key-value store for multiplayer game sessions';
COMMENT ON COLUMN kv_store_55cb4193.key IS 'Unique key for the stored value';
COMMENT ON COLUMN kv_store_55cb4193.value IS 'JSON value stored for the key';
COMMENT ON COLUMN kv_store_55cb4193.created_at IS 'Timestamp when the record was created';
COMMENT ON COLUMN kv_store_55cb4193.updated_at IS 'Timestamp when the record was last updated';
