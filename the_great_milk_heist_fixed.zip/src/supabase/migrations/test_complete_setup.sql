-- COMPLETE SETUP TEST
-- Run this to verify your entire Supabase setup is correct
-- This will create a test user, verify the trigger works, then clean up

DO $$
DECLARE
  test_user_id UUID;
  test_email TEXT := 'test_' || floor(random() * 10000)::TEXT || '@test.com';
  test_username TEXT := 'TestUser_' || floor(random() * 10000)::TEXT;
  test_password TEXT := 'testpassword123';
  profile_exists BOOLEAN;
BEGIN
  RAISE NOTICE '========================================';
  RAISE NOTICE 'STARTING COMPLETE SETUP TEST';
  RAISE NOTICE '========================================';
  
  -- Test 1: Check tables exist
  RAISE NOTICE '';
  RAISE NOTICE 'Test 1: Checking if tables exist...';
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users' AND table_schema = 'public') THEN
    RAISE NOTICE '✓ users table exists';
  ELSE
    RAISE WARNING '✗ users table MISSING';
  END IF;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'friend_requests' AND table_schema = 'public') THEN
    RAISE NOTICE '✓ friend_requests table exists';
  ELSE
    RAISE WARNING '✗ friend_requests table MISSING';
  END IF;
  
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'session_invites' AND table_schema = 'public') THEN
    RAISE NOTICE '✓ session_invites table exists';
  ELSE
    RAISE WARNING '✗ session_invites table MISSING';
  END IF;
  
  -- Test 2: Check trigger exists
  RAISE NOTICE '';
  RAISE NOTICE 'Test 2: Checking if trigger exists...';
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created') THEN
    RAISE NOTICE '✓ on_auth_user_created trigger exists';
  ELSE
    RAISE WARNING '✗ on_auth_user_created trigger MISSING';
  END IF;
  
  -- Test 3: Check function exists
  RAISE NOTICE '';
  RAISE NOTICE 'Test 3: Checking if functions exist...';
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'handle_new_user') THEN
    RAISE NOTICE '✓ handle_new_user function exists';
  ELSE
    RAISE WARNING '✗ handle_new_user function MISSING';
  END IF;
  
  IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'create_user_profile') THEN
    RAISE NOTICE '✓ create_user_profile function exists (fallback)';
  ELSE
    RAISE WARNING '✗ create_user_profile function MISSING (run create_user_profile_function.sql)';
  END IF;
  
  -- Test 4: Create test auth user to verify trigger
  RAISE NOTICE '';
  RAISE NOTICE 'Test 4: Testing trigger with dummy user...';
  RAISE NOTICE 'Creating test user: %', test_email;
  
  -- Insert a test user into auth.users (simulating signup)
  INSERT INTO auth.users (
    id,
    instance_id,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_user_meta_data,
    created_at,
    updated_at,
    aud,
    role
  ) VALUES (
    gen_random_uuid(),
    '00000000-0000-0000-0000-000000000000'::UUID,
    test_email,
    crypt(test_password, gen_salt('bf')),
    NOW(),
    jsonb_build_object('username', test_username),
    NOW(),
    NOW(),
    'authenticated',
    'authenticated'
  )
  RETURNING id INTO test_user_id;
  
  RAISE NOTICE 'Test user created with ID: %', test_user_id;
  
  -- Wait a moment for trigger to fire
  PERFORM pg_sleep(1);
  
  -- Check if user profile was created
  SELECT EXISTS (SELECT 1 FROM public.users WHERE id = test_user_id) INTO profile_exists;
  
  IF profile_exists THEN
    RAISE NOTICE '✓ Trigger successfully created user profile!';
  ELSE
    RAISE WARNING '✗ Trigger DID NOT create user profile';
    RAISE WARNING 'Attempting fallback RPC function...';
    
    -- Test the RPC fallback
    BEGIN
      PERFORM public.create_user_profile(test_user_id, test_username);
      
      SELECT EXISTS (SELECT 1 FROM public.users WHERE id = test_user_id) INTO profile_exists;
      
      IF profile_exists THEN
        RAISE NOTICE '✓ Fallback RPC function created user profile!';
      ELSE
        RAISE WARNING '✗ Fallback RPC function FAILED';
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING '✗ Fallback RPC function ERROR: %', SQLERRM;
    END;
  END IF;
  
  -- Test 5: Verify RLS policies
  RAISE NOTICE '';
  RAISE NOTICE 'Test 5: Checking RLS policies...';
  IF EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'users' AND schemaname = 'public') THEN
    RAISE NOTICE '✓ RLS policies exist for users table';
  ELSE
    RAISE WARNING '✗ No RLS policies for users table';
  END IF;
  
  -- Cleanup
  RAISE NOTICE '';
  RAISE NOTICE 'Test 6: Cleaning up test data...';
  DELETE FROM public.users WHERE id = test_user_id;
  DELETE FROM auth.users WHERE id = test_user_id;
  RAISE NOTICE '✓ Test data cleaned up';
  
  -- Final summary
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  RAISE NOTICE 'TEST COMPLETE';
  RAISE NOTICE '========================================';
  
  IF profile_exists THEN
    RAISE NOTICE '';
    RAISE NOTICE '✓✓✓ ALL TESTS PASSED ✓✓✓';
    RAISE NOTICE 'Your setup is working correctly!';
    RAISE NOTICE 'You can now sign up and play the game.';
  ELSE
    RAISE NOTICE '';
    RAISE NOTICE '✗✗✗ SETUP HAS ISSUES ✗✗✗';
    RAISE NOTICE 'The trigger is not creating user profiles.';
    RAISE NOTICE 'Please run:';
    RAISE NOTICE '  1. /supabase/migrations/20250107000001_fix_trigger.sql';
    RAISE NOTICE '  2. /supabase/migrations/create_user_profile_function.sql';
    RAISE NOTICE 'Then run this test again.';
  END IF;
  
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  
END $$;
