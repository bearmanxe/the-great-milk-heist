-- Create a function that can be called from the client to create a user profile
-- This is a fallback when the trigger doesn't work
-- SECURITY DEFINER allows it to bypass RLS

CREATE OR REPLACE FUNCTION public.create_user_profile(
  user_id UUID,
  user_name TEXT
)
RETURNS JSONB
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSONB;
BEGIN
  -- Check if user already has a profile
  IF EXISTS (SELECT 1 FROM public.users WHERE id = user_id) THEN
    RETURN jsonb_build_object(
      'success', true,
      'message', 'User profile already exists',
      'already_existed', true
    );
  END IF;
  
  -- Create the user profile
  INSERT INTO public.users (
    id, 
    username, 
    unlocked_cosmetics, 
    weapon_upgrades, 
    achievements, 
    total_coins, 
    selected_cosmetic, 
    stats, 
    friends
  )
  VALUES (
    user_id,
    user_name,
    ARRAY['default']::TEXT[],
    '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
    ARRAY[]::TEXT[],
    0,
    '🧑',
    '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
    ARRAY[]::UUID[]
  );
  
  RETURN jsonb_build_object(
    'success', true,
    'message', 'User profile created successfully',
    'already_existed', false
  );
  
EXCEPTION
  WHEN unique_violation THEN
    -- Username is taken, try with suffix
    INSERT INTO public.users (
      id, 
      username, 
      unlocked_cosmetics, 
      weapon_upgrades, 
      achievements, 
      total_coins, 
      selected_cosmetic, 
      stats, 
      friends
    )
    VALUES (
      user_id,
      user_name || '_' || substr(user_id::text, 1, 4),
      ARRAY['default']::TEXT[],
      '{"damage": 0, "attackSpeed": 0, "range": 0, "knockback": 0}'::JSONB,
      ARRAY[]::TEXT[],
      0,
      '🧑',
      '{"roomsCleared": 0, "enemiesKilled": 0, "bossesDefeated": 0, "coinsEarned": 0, "hasWonOnce": false}'::JSONB,
      ARRAY[]::UUID[]
    );
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'User profile created with modified username (conflict)',
      'already_existed', false,
      'username_modified', true
    );
    
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', SQLERRM,
      'error', true
    );
END;
$$ LANGUAGE plpgsql;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION public.create_user_profile(UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_user_profile(UUID, TEXT) TO anon;

-- Test the function (uncomment to test with a dummy user ID)
-- SELECT public.create_user_profile('00000000-0000-0000-0000-000000000000'::UUID, 'TestUser');
