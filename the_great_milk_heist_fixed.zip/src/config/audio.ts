// Background Music Configuration
// 
// SETUP INSTRUCTIONS:
// 1. Copy your "Milk Mayhem.mp4" file to the /public/assets/ folder
// 2. You can keep the name or rename it to "background-music.mp4"
// 3. Update the URL below to match the filename
// 4. Refresh the page!
//
// The file will be served from your public folder.
// Make sure the file is in: /public/assets/background-music.mp4

// TODO: Replace this with your actual music file URL
// Option 1: Use a public URL (from Dropbox, Google Drive, Cloudinary, etc.)
// For Dropbox: Get a share link, then change ?dl=0 to ?dl=1 at the end
// Example: https://www.dropbox.com/scl/fi/xxxxx/background%20music.mp4?rlkey=xxxxx&dl=1
export const BACKGROUND_MUSIC_URL: string | null = 'PASTE_YOUR_DROPBOX_DIRECT_LINK_HERE';
//
// Option 2: Place the file in /public/assets/ and uncomment this line:
// export const BACKGROUND_MUSIC_URL: string | null = '/assets/background-music.mp4';
//
// Option 3: Use chiptune music only:
// export const BACKGROUND_MUSIC_URL: string | null = null;

export const BACKGROUND_MUSIC_CONFIG = {
  enabled: true, // Set to false to disable background music entirely
  autoPlay: true,
  defaultVolume: 0.3, // 30% (matches soundManager volume)
  loop: true,
  useChiptuneIfNoFile: true, // Fall back to chiptune if no URL provided
};